# 102203821_Topsis
TOPSIS (Technique for Order Preference by Similarity to Ideal Solution) is a decision-making method used for ranking alternatives based on multiple criteria.

## Installation

You can install this package using pip:

```bash
pip install 102203821_Topsis
